/**
 * Copyright (c) 2018 - 2019, Nordic Semiconductor ASA
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 *
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
#include <ctype.h>
#include "nrf_cli.h"
#include "nrf_log.h"
#include "sdk_common.h"
#include "nrf_stack_guard.h"

#include "ble_gap.h"
#include "ble_gatt.h"
#include "nrf_strerror.h"



#define CLI_EXAMPLE_MAX_CMD_CNT (20u)
#define CLI_EXAMPLE_MAX_CMD_LEN (33u)
#define CLI_EXAMPLE_VALUE_BIGGER_THAN_STACK     (20000u)


extern void GetTime(void);
extern void StartTime(void);
extern void setTesterMode(void);
extern void setDummyMode(void);
extern void     init_software();
extern void     toggleLed();
extern void sendsync();
extern void Connect(void);
extern void Disconnect(void);
extern void  initThroughputTest();


extern void StartADV();
extern void disconnect();
extern void StartSCN();


extern void StartBTSTX();
extern void StopBTSTX();

extern void StartThroughputTest();

extern void SendCMD(uint16_t value);
/* Command handlers */
static void cmd_print_param(nrf_cli_t const * p_cli, size_t argc, char **argv)
{
    for (size_t i = 1; i < argc; i++)
    {
        nrf_cli_print(p_cli, "argv[%d] = %s", i, argv[i]);
    }
}

static void cmd_print_all(nrf_cli_t const * p_cli, size_t argc, char **argv)
{
    for (size_t i = 1; i < argc; i++)
    {
        nrf_cli_fprintf(p_cli, NRF_CLI_NORMAL, "%s ", argv[i]);
    }
    nrf_cli_fprintf(p_cli, NRF_CLI_NORMAL, "\n");
}

static void cmd_print(nrf_cli_t const * p_cli, size_t argc, char **argv)
{
    ASSERT(p_cli);
    ASSERT(p_cli->p_ctx && p_cli->p_iface && p_cli->p_name);

    if ((argc == 1) || nrf_cli_help_requested(p_cli))
    {
        nrf_cli_help_print(p_cli, NULL, 0);
        return;
    }

    if (argc != 2)
    {
        nrf_cli_error(p_cli, "%s: bad parameter count", argv[0]);
        return;
    }

    nrf_cli_error(p_cli, "%s: unknown parameter: %s", argv[0], argv[1]);
}




static void cmd_TimerTest(nrf_cli_t const * p_cli, size_t argc, char **argv)
{       
    static const nrf_cli_getopt_option_t opt[] = 
    {
        NRF_CLI_OPT("--begin","-b","begin timer"),
        NRF_CLI_OPT("--stop","-s","stop timer and get time")
    };

    if (nrf_cli_help_requested(p_cli))
    {
        nrf_cli_help_print(p_cli, opt, ARRAY_SIZE(opt));
        return;
    }

    if (!strcmp(argv[1], "-b") || !strcmp(argv[1], "--begin"))
    {   
        StartTime();
        return;
    }

    if (!strcmp(argv[1], "-s") || !strcmp(argv[1], "--stop"))
    {   
        GetTime();
        return;
    }

    if (!strcmp(argv[2], "-d") || !strcmp(argv[2], "--dundy"))
    {        
        nrf_cli_print(p_cli, "-d in the second position, interesting choice! \n");
        return;
    }
    nrf_cli_error(p_cli, "%s: unknown parameter: %s", argv[0], argv[1]);
}

static void cmd_Setmode(nrf_cli_t const * p_cli, size_t argc, char **argv)
{       
    static const nrf_cli_getopt_option_t opt[] = 
    {
        NRF_CLI_OPT("--tester","-t","Tester mode"),
        NRF_CLI_OPT("--dummy","-d","dummy mode")
    };
  
    if (nrf_cli_help_requested(p_cli))
    {
        nrf_cli_help_print(p_cli, opt, ARRAY_SIZE(opt));
        return;
    }
  
    if (!strcmp(argv[1], "-t") || !strcmp(argv[1], "--tester"))
    {   
       setTesterMode();
        return;
    }
  
    if (!strcmp(argv[1], "-d") || !strcmp(argv[1], "--dummy"))
    {   
        setDummyMode();
        return;
    }
        if (!strcmp(argv[1], "-a") || !strcmp(argv[1], "--A"))
    {   
        //ConnectA();
        return;
    }
         if (!strcmp(argv[1], "-b") || !strcmp(argv[1], "--B"))
    {   
        //ConnectB();
        return;
    }
  
  
  
    nrf_cli_error(p_cli, "%s: unknown parameter: %s", argv[0], argv[1]);
}




static void cmd_TrhouphutTest(nrf_cli_t const * p_cli, size_t argc, char **argv)
{       
    static const nrf_cli_getopt_option_t opt[] = 
    {
        NRF_CLI_OPT("--init","-i","initialize"),
        NRF_CLI_OPT("--start","-s","start")
    };

    if (nrf_cli_help_requested(p_cli))
    {
        nrf_cli_help_print(p_cli, opt, ARRAY_SIZE(opt));
        return;
    }

    if (!strcmp(argv[1], "-i") || !strcmp(argv[1], "--init"))
    {   
       initThroughputTest();
        return;
    }

    if (!strcmp(argv[1], "-s") || !strcmp(argv[1], "--start"))
    {   
        setDummyMode();
        return;
    }
	initThroughputTest();

}




static void cmd_ToggleLed(nrf_cli_t const * p_cli, size_t argc, char **argv)
{       
   
    if (nrf_cli_help_requested(p_cli))
    {
         nrf_cli_print(p_cli, "ToggleLed");
          return;
    }
    toggleLed();    
}

static void cmd_aboute(nrf_cli_t const * p_cli, size_t argc, char **argv)
{
    UNUSED_PARAMETER(argc);
    UNUSED_PARAMETER(argv);
    if (nrf_cli_help_requested(p_cli))
    {
        nrf_cli_help_print(p_cli, NULL, 0);
        return;
    }
   // init_software();
    nrf_cli_fprintf(p_cli, NRF_CLI_OPTION,            

                     "\n"
                     "                                                  \n"
                     "                &&&&&&&&&&&&&&&&&&                \n"
                     "             &&  &&&&&&&&&&&&&&&&  &&             \n"
                     "           &% /&                 .&* &&           \n"
                     "        &&  &&                      &&  &&        \n"
                     "      &# (&                            &/ %&      \n"
                     "   &&  &&                                &&  &&   \n"
                     "   &  &&&&&&&&&&&&&&          &&&&&&&&&&&&&&  &   \n"
                     "   &  &&&&&&&&&&&&*&          &*&&&&&&&&&&&&  &   \n"
                     "   &  &         &&*&          &*&&         &  &   \n"
                     "   &  &         &&*&          &*&&         &  &   \n"
                     "   &  &         &&*&          &*&&         &  &   \n"
                     "   &  &         &&*&          &*&&         &  &   \n"
                     "   &&  &&       &&*            *&&       &&  &&   \n"
                     "      &( &&                            &# %&      \n"
                     "        &&  &&                      &&  &&        \n"
                     "           &# #&                  &( &&           \n"
                     "             &&  &&&&&&&&&&&&&&&&  &&             \n"
                     "                &&&&&&&&&&&&&&&&&&                \n"
                     "\n");
nrf_cli_print(p_cli, "                        HBH               \n");
}


/**
 * @brief Command set array
 * */
NRF_CLI_CMD_REGISTER(about, NULL, "about", cmd_aboute);

NRF_CLI_CREATE_STATIC_SUBCMD_SET(m_sub_print)
{
    NRF_CLI_CMD(all,   NULL, "Print all entered parameters.", cmd_print_all),
    NRF_CLI_CMD(param, NULL, "Print each parameter in new line.", cmd_print_param),
    NRF_CLI_SUBCMD_SET_END
};

NRF_CLI_CMD_REGISTER(print, &m_sub_print, "print", cmd_print);
NRF_CLI_CMD_REGISTER(Timer_test, NULL, "starts RTC timer", cmd_TimerTest);

NRF_CLI_CMD_REGISTER(Set_Mode, NULL, "sets the role of the device", cmd_Setmode);

NRF_CLI_CMD_REGISTER(ToggleLed, NULL, "ToggleLed", cmd_ToggleLed);



///////////////
extern void gatt_mtu_set(uint16_t att_mtu);
extern void preferred_phy_set(ble_gap_phys_t * p_phy);
extern void conn_evt_len_ext_set(bool status);
extern void data_len_set(uint8_t value);
extern void connection_interval_set(uint16_t value);
extern void current_config_print(nrf_cli_t const * p_cli);
extern void GattSet();
extern char const * phy_str(ble_gap_phys_t);
extern bool is_tester_board(void);
extern void test_begin(void);

extern void sendsync();
extern void SetTXdelay(uint16_t a);
extern float Throughput;

static void att_mtu_size_set(nrf_cli_t const * p_cli, uint16_t value)
{
    if (value < BLE_GATT_ATT_MTU_DEFAULT || value > NRF_SDH_BLE_GATT_MAX_MTU_SIZE)
    {
        nrf_cli_fprintf(p_cli, NRF_CLI_ERROR, "Invalid setting: %d.\n", value);
        return;
    }

    gatt_mtu_set(value);
    nrf_cli_fprintf(p_cli, NRF_CLI_NORMAL, "ATT MTU size set to %d bytes.\n", value);
}


static void conn_interval_set(nrf_cli_t const * p_cli, uint16_t value)
{
    connection_interval_set(value);
    nrf_cli_fprintf(p_cli, NRF_CLI_NORMAL, "Connection interval set to %d units.\n", value);
}


static void dl_set(nrf_cli_t const * p_cli, uint32_t value)
{
    // These are the stack default values.
    if (value < 27 || value > 251)
    {
        nrf_cli_fprintf(p_cli, NRF_CLI_ERROR, "Invalid setting: %d.\n", value);
        return;
    }

    data_len_set(value);
    nrf_cli_fprintf(p_cli, NRF_CLI_NORMAL, "Data length set to %d.\n", value);
}


static void cele_set(nrf_cli_t const * p_cli, bool enable)
{
    nrf_cli_fprintf(
        p_cli, NRF_CLI_NORMAL, "Connection event length extension %s.\n", enable ? "on" : "off");
    conn_evt_len_ext_set(enable);
}


static void phy_set(nrf_cli_t const * p_cli, uint8_t value)
{
    ble_gap_phys_t phy =
    {
        .rx_phys = value,
        .tx_phys = value,
    };

    preferred_phy_set(&phy);
    nrf_cli_fprintf(p_cli, NRF_CLI_NORMAL, "Preferred PHY set to %s.\n", phy_str(phy));
}


static void cmd_conn_interval_7_5_set(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    conn_interval_set(p_cli, (uint16_t)(MSEC_TO_UNITS(7.5, UNIT_1_25_MS)));
}


static void cmd_conn_interval_50_set(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    conn_interval_set(p_cli, (uint16_t)(MSEC_TO_UNITS(50, UNIT_1_25_MS)));
}


static void cmd_conn_interval_400_set(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    conn_interval_set(p_cli, (uint16_t)(MSEC_TO_UNITS(400, UNIT_1_25_MS)));
}


NRF_CLI_CREATE_STATIC_SUBCMD_SET(m_conn_interval_cmds)
{
    NRF_CLI_CMD(7.5, NULL, "Use a 7.5ms connection interval", cmd_conn_interval_7_5_set),
    NRF_CLI_CMD(50,  NULL, "use a 50ms connection interval",  cmd_conn_interval_50_set),
    NRF_CLI_CMD(400, NULL, "Use a 400ms connection interval", cmd_conn_interval_400_set),
    NRF_CLI_SUBCMD_SET_END
};


static void cmd_cele_on_set(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    cele_set(p_cli, true);
}


static void cmd_cele_off_set(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    cele_set(p_cli, false);
}


NRF_CLI_CREATE_STATIC_SUBCMD_SET(m_cele_cmd)
{
    NRF_CLI_CMD(on,  NULL, "Turn Connection Event Length Extension on",  cmd_cele_on_set),
    NRF_CLI_CMD(off, NULL, "Turn Connection Event Length Extension off", cmd_cele_off_set),
    NRF_CLI_SUBCMD_SET_END
};


static void cmd_phy_1m_set(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    phy_set(p_cli, BLE_GAP_PHY_1MBPS);
}


static void cmd_phy_2m_set(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    phy_set(p_cli, BLE_GAP_PHY_2MBPS);
}


#ifdef NRF52840_XXAA
static void cmd_phy_coded_set(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    phy_set(p_cli, BLE_GAP_PHY_CODED);
}
#endif


NRF_CLI_CREATE_STATIC_SUBCMD_SET(m_prephy_cmds)
{
    NRF_CLI_CMD(1M,    NULL, "Set preferred PHY to 1Mbps", cmd_phy_1m_set),
    NRF_CLI_CMD(2M,    NULL, "Set preferred PHY to 2Mbps", cmd_phy_2m_set),
#ifdef NRF52840_XXAA
    NRF_CLI_CMD(coded, NULL, "Set preferred PHY to Coded", cmd_phy_coded_set),
#endif
    NRF_CLI_SUBCMD_SET_END
};


static void att_mtu_cmd(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    if ((argc == 1) || nrf_cli_help_requested(p_cli))
    {
        nrf_cli_help_print(p_cli, NULL, 0);
    }
    else if (argc == 2)
    {
        att_mtu_size_set(p_cli, strtol(argv[1], NULL, 10));
    }
    else
    {
        nrf_cli_fprintf(p_cli, NRF_CLI_ERROR, "%s:%s\n", argv[0], " wrong parameter list");
    }
}


static void data_len_cmd(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    if ((argc == 1) || nrf_cli_help_requested(p_cli))
    {
        nrf_cli_help_print(p_cli, NULL, 0);
    }
    else if (argc == 2)
    {
        dl_set(p_cli, strtol(argv[1], NULL, 10));
    }
    else
    {
        nrf_cli_fprintf(p_cli, NRF_CLI_ERROR, "%s:%s\n", argv[0], " wrong parameter list");
    }
}


static void config_print_cmd(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    current_config_print(p_cli);
     GattSet();
}


static void gap_evt_len_cmd(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    nrf_cli_fprintf(p_cli, NRF_CLI_NORMAL, "This value cannot be set at runtime.\n"
                                           "Modify NRF_SDH_BLE_GAP_EVENT_LENGTH in sdk_config.h "
                                           "and recompile the application.\n");
}


static void default_cmd(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    if ((argc == 1) || nrf_cli_help_requested(p_cli))
    {
        nrf_cli_help_print(p_cli, NULL, 0);
    }
    else
    {
        nrf_cli_fprintf(p_cli,
                        NRF_CLI_ERROR,
                        "%s:%s%s\n",
                        argv[0],
                        " unknown parameter: ",
                        argv[1]);
    }
}


NRF_CLI_CREATE_STATIC_SUBCMD_SET(m_test_config_cmds)
{
    NRF_CLI_CMD(att_mtu,            NULL,                  "Configure ATT MTU size",                  att_mtu_cmd),
    NRF_CLI_CMD(data_length,        NULL,                  "Configure data length",                   data_len_cmd),
    NRF_CLI_CMD(conn_evt_len_ext,   &m_cele_cmd,           "Enable or disable Data Length Extension", default_cmd),
    NRF_CLI_CMD(conn_interval,      &m_conn_interval_cmds, "Configure GAP connection interval",       default_cmd),
    NRF_CLI_CMD(print,              NULL,                  "Print current configuration",             config_print_cmd),
    NRF_CLI_CMD(phy,                &m_prephy_cmds,        "Configure preferred PHY",                 default_cmd),
    NRF_CLI_CMD(gap_evt_len,        NULL,                  "Configure GAP event length",              gap_evt_len_cmd),
    NRF_CLI_SUBCMD_SET_END
};

static void cmd_test_run(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
    if (is_tester_board())
    {
        test_begin();
    }
    else
    {
        nrf_cli_fprintf(p_cli, NRF_CLI_ERROR, "Wrong board setup!\n");
    }
}

static void cmd_test_startadv(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
 StartADV();

}

static void cmd_test_startscn(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
 StartSCN();

}

static void cmd_test_disconnect(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{

disconnect();



}



static void cmd_sync(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
 sendsync();
}

static void cmd_setTxDelay(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
 nrf_cli_fprintf(p_cli,NRF_CLI_NORMAL , "Invalid setting: %d.\n", strtol(argv[1], NULL, 10));
 SetTXdelay(strtol(argv[1], NULL, 10));
}

static void cmd_SendCMD(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
 nrf_cli_fprintf(p_cli,NRF_CLI_NORMAL , "Sending OPCODE: %d.\n", strtol(argv[1], NULL, 10));
 SendCMD(strtol(argv[1], NULL, 10));
}
NRF_CLI_CMD_REGISTER(SendCMD,    NULL,                "sendCMD",          cmd_SendCMD);

static void cmd_StartThroughputTest(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
 nrf_cli_fprintf(p_cli,NRF_CLI_NORMAL , "Starting Throughput Test:\n");
 StartThroughputTest(strtol(argv[1], NULL, 10));
}
NRF_CLI_CMD_REGISTER(measureTP,    NULL,                "sendCMD",          cmd_StartThroughputTest);



static void cmd_test_start(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
   StartBTSTX();  
}
NRF_CLI_CMD_REGISTER(start,    NULL,                "Start Receiving",          cmd_test_start);

static void cmd_test_stop(nrf_cli_t const * p_cli, size_t argc, char ** argv)
{
   StopBTSTX();  
}
NRF_CLI_CMD_REGISTER(stop,    NULL,                "stop receiving",          cmd_test_stop);





NRF_CLI_CMD_REGISTER(config, &m_test_config_cmds, "Configure the example", default_cmd);
NRF_CLI_CMD_REGISTER(run,    NULL,                "Run the test",          cmd_test_run);
NRF_CLI_CMD_REGISTER(init,    NULL,                "Trhoughput test",           cmd_TrhouphutTest);
NRF_CLI_CMD_REGISTER(sync,    NULL,                "Trhoughput test",           cmd_sync);




NRF_CLI_CMD_REGISTER(adv,    NULL,                "start advertising",          cmd_test_startadv);
NRF_CLI_CMD_REGISTER(scn,    NULL,                "start scan",          cmd_test_startscn);
NRF_CLI_CMD_REGISTER(dis,    NULL,                "disc",          cmd_test_disconnect);

NRF_CLI_CMD_REGISTER(txrate,    NULL,                "disc",          cmd_setTxDelay);
