#include "init.h"
#include "app.h"
#include "CustomTX.h"
#include "nrf_sdh_soc.h"

static bool debug=false; 
static uint32_t mainticks=0;




static void time_slot_soc_evt_handler(uint32_t evt_id, void * p_context)
{
    nrf_evt_signal_handler(evt_id);
}

NRF_SDH_SOC_OBSERVER(m_time_slot_soc_observer,0, time_slot_soc_evt_handler, NULL);






void GetTime(void)
 {
     counter_stop();
     uint32_t time_ms      = counter_get();
     debug=false;  
     mainticks=0;
     NRF_LOG_RAW_INFO("time in ms = %d\n", time_ms);
 }

 void StartTime(void)
 {
     // counter_start();
      debug=true;  
 }

  void toggleLed(void)
 {    
      if (bsp_board_led_state_get(1)) 
      {
      bsp_board_led_off(1);
      }
      else 
      {
      bsp_board_led_on(1);      
      }
      init_BLE_TEST_SERVICE();          
 }


//void sync()
//{
//test_params_t2 config;
//memcpy(&config, &m_test_params, sizeof(m_test_params));
//SEND_SYNC_BTS(&m_BTSclt , config);
//}
//
 void idle_task(void * p_context)
{
       
        for (;;)
        {
               if (is_test_ready())
               {
                   NRF_LOG_RAW_INFO("Test started");
                   m_run_test = true;
                   test_run();
               }      
                
               if (debug==true)
               {                    
                  // mainticks ++;
                  // NRF_LOG_RAW_INFO("mainticks = %d\n", mainticks);  ;
                   NRF_LOG_RAW_INFO("mainticks = \n");
                  

                 // startlistening();
               }

               if (BTS_tx_notif_enabled)
               {                 
                   tx_run2();              
               }

               if (NRF_LOG_PROCESS() == false)
               {
                   nrf_pwr_mgmt_run();
               }
               task_yield();
        }
}


int main(void)
{      




timeslot_sd_init();




        init_hardware();  
        init_software();    
        task_manager_start(idle_task, NULL);
}
