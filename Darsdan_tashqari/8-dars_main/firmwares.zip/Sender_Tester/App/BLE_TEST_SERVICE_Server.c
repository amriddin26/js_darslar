#include "BLE_TEST_SERVICE.h"

#include "nrf_error.h"
#include "sdk_common.h"
#include "app_error.h"
#include "ble_err.h"
#include "ble_srv_common.h"

#define NRF_LOG_MODULE_NAME BTS
#include "nrf_log.h"
NRF_LOG_MODULE_REGISTER();

void BTS_init(nrf_ble_amts_t2 * p_ctx, amts_evt_handler_t2 evt_handler)
{
    ret_code_t    err_code;
    uint16_t      service_handle;
    ble_uuid_t    ble_uuid;
    ble_uuid128_t base_uuid = {BTS_UUID_BASE};

    err_code = sd_ble_uuid_vs_add(&base_uuid, &(p_ctx->uuid_type));
    APP_ERROR_CHECK(err_code);

    ble_uuid.type = p_ctx->uuid_type;
    ble_uuid.uuid = BTS_SERVICE_UUID;

    // Add service.
    err_code = sd_ble_gatts_service_add(BLE_GATTS_SRVC_TYPE_PRIMARY, &ble_uuid, &service_handle);
    APP_ERROR_CHECK(err_code);



    // Add customTX char.
    ble_add_char_params_t BTS_TX_params;
    memset(&BTS_TX_params, 0, sizeof(BTS_TX_params));

    BTS_TX_params.uuid              = BTS_TX_UUID;
    BTS_TX_params.uuid_type         = p_ctx->uuid_type;
    BTS_TX_params.max_len           = NRF_SDH_BLE_GATT_MAX_MTU_SIZE;
    BTS_TX_params.char_props.notify = 1;
    BTS_TX_params.cccd_write_access = SEC_OPEN;
    BTS_TX_params.is_var_len        = 1;

    err_code = characteristic_add(service_handle, &BTS_TX_params, &(p_ctx->BTS_TX_char_handles));
    APP_ERROR_CHECK(err_code);



   // Add Button characteristic.
    ble_add_char_params_t SYNC_char_params;
    memset(&SYNC_char_params, 0, sizeof(SYNC_char_params));
    SYNC_char_params.uuid              = SYNC2_char_params_UUID;
    SYNC_char_params.uuid_type         = p_ctx->uuid_type;
    SYNC_char_params.init_len          = sizeof(test_params_t2);
    SYNC_char_params.max_len           = sizeof(test_params_t2);
    SYNC_char_params.char_props.read   = 1;
   // SYNC_char_params.char_props.notify = 1;
    SYNC_char_params.char_props.write   = 1;
    SYNC_char_params.read_access        = SEC_OPEN;
    SYNC_char_params.write_access= SEC_OPEN;

    err_code = characteristic_add(service_handle,
                                  &SYNC_char_params,
                                  &p_ctx->SYNC_char_handles);
    
    // Add BLE CMD Char.
    ble_add_char_params_t BLE_CMD_params;
    memset(&BLE_CMD_params, 0, sizeof(BLE_CMD_params));
    BLE_CMD_params.uuid              = CMD_BLE_UUID;
    BLE_CMD_params.uuid_type         = p_ctx->uuid_type;
    BLE_CMD_params.init_len          = sizeof(cmd_t);
    BLE_CMD_params.max_len           = sizeof(cmd_t);
    BLE_CMD_params.char_props.read   = 1;
    BLE_CMD_params.char_props.write  = 1;
    BLE_CMD_params.read_access       = SEC_OPEN;
    BLE_CMD_params.write_access      = SEC_OPEN;
    err_code = characteristic_add(service_handle,
                                  &BLE_CMD_params,
                                  &p_ctx->CMD_BLE_char_handles);
    

    p_ctx->evt_handler = evt_handler;
}

/**@brief Function for handling the Connect event.
 *
 * @param     p_ctx       Pointer to the AMTS structure.
 * @param[in] p_ble_evt  Event received from the BLE stack.
 */
static void on_connect(nrf_ble_amts_t2 * p_ctx, ble_evt_t const * p_ble_evt)
{
    p_ctx->conn_handle = p_ble_evt->evt.gap_evt.conn_handle;
}


/**@brief Function for handling the Disconnect event.
 *
 * @param     p_ctx         Pointer to the AMTS structure.
 * @param[in] p_ble_evt     Event received from the BLE stack.
 */
static void on_disconnect(nrf_ble_amts_t2 * p_ctx, ble_evt_t const * p_ble_evt)
{
    p_ctx->conn_handle = BLE_CONN_HANDLE_INVALID;
}


/**@brief Function for handling the TX_COMPLETE event.
 *
 * @param   p_ctx   Pointer to the AMTS structure.
 */
static void on_tx_complete(nrf_ble_amts_t2 * p_ctx)
{
   // if (p_ctx->busy)
   // {
   //     p_ctx->busy = false;
 ////       char_notification_send(p_ctx);
   // }
}


/**@brief Function for handling the Write event.
 *
 * @param     p_ctx       Pointer to the AMTS structure.
 * @param[in] p_ble_evt   Event received from the BLE stack.
 */
static void on_write(nrf_ble_amts_t2 * p_ctx, ble_evt_t const * p_ble_evt)
{
    ble_gatts_evt_write_t const * p_evt_write = &p_ble_evt->evt.gatts_evt.params.write;
 
    //Custom chart subscribed
    if ((p_evt_write->handle == p_ctx->SYNC_char_handles.value_handle))
    {   
       NRF_LOG_INFO("RECEIVEDdd DATA BYTE1: %d", p_evt_write->data[0]);
       NRF_LOG_INFO("RECEIVEDdd DATA BYTE2: %d", p_evt_write->data[1]);
       NRF_LOG_INFO("RECEIVEDdd DATA BYTE3: %d", p_evt_write->data[2]);
       NRF_LOG_INFO("RECEIVEDdd DATA BYTE4: %d", p_evt_write->data[3]);
       NRF_LOG_INFO("RECEIVEDdd DATA BYTE5: %d", p_evt_write->data[4]);
       NRF_LOG_INFO("RECEIVEDdd DATA BYTE6: %d", p_evt_write->data[5]);
       NRF_LOG_INFO("RECEIVEDdd DATA BYTE7: %d", p_evt_write->data[6]);      
       test_params_t2 config ;    
       memset(&config, 0, sizeof(test_params_t2));
       memcpy(&config, &p_evt_write->data[0] , sizeof(test_params_t2));
       nrf_ble_amts_evt_t2 evt;
       evt.evt_type= SYNC_INCOMING2;
       evt.config_data=config;
       p_ctx->evt_handler(evt);
    }
     
    //BTX TX ENabled
    if ((p_evt_write->handle == p_ctx->BTS_TX_char_handles.cccd_handle) && (p_evt_write->len == 2))
    {

        // CCCD written, call the application event handler.
        nrf_ble_amts_evt_t2 evt;

        if (ble_srv_is_notification_enabled(p_evt_write->data))
        {
         NRF_LOG_INFO("BTS TX Notification Enabled");
           evt.evt_type = BTS_TX_EVT_NOTIF_ENABLED;
        }
        else
        {
            evt.evt_type = BTS_TX_EVT_NOTIF_DISABLED;
            NRF_LOG_INFO("BTS TX Notification Disabled");
        }

        p_ctx->evt_handler(evt);
    }


    //CT CMD 
    if ((p_evt_write->handle == p_ctx->CMD_BLE_char_handles.value_handle))
    {   
       NRF_LOG_INFO("RECEIVEDdd Command");
       cmd_t command;      

       memset(&command, 0, sizeof(command));
       memcpy(&command, &p_evt_write->data[0] , sizeof(command));
       NRF_LOG_INFO("data1:  %d , data2:  %d , data3:  %d ,data4:  %d , " ,p_evt_write->data[0],p_evt_write->data[1],p_evt_write->data[2],p_evt_write->data[3]);
       NRF_LOG_INFO("OP code: %d Data: %d " ,command.opcode,command.data.data1);
       nrf_ble_amts_evt_t2 evt;
       evt.evt_type= CMD_INCOMING;
       evt.command=command;
       p_ctx->evt_handler(evt);




    }






}


void BTS_on_ble_evt(ble_evt_t const * p_ble_evt, void * p_context)
{
    nrf_ble_amts_t2 * p_ctx = (nrf_ble_amts_t2 *)p_context;

    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GAP_EVT_CONNECTED:
            on_connect(p_ctx, p_ble_evt);
            break;

        case BLE_GAP_EVT_DISCONNECTED:
            on_disconnect(p_ctx, p_ble_evt);
            break;

        case BLE_GATTS_EVT_WRITE:
            on_write(p_ctx, p_ble_evt);
            break;

        case BLE_GATTS_EVT_HVN_TX_COMPLETE:
            on_tx_complete(p_ctx);
            break;

        default:
            break;
    }
}


void  BTS_TX_Notify(nrf_ble_amts_t2 * p_ctx , sensor_sim_t2 * p_data  )
{   

    ble_gatts_hvx_params_t  params;       
    uint16_t               length = sizeof(sensor_sim_t2);

    VERIFY_PARAM_NOT_NULL(p_ctx);
    
    if (p_ctx->conn_handle == BLE_CONN_HANDLE_INVALID) 
    {
        return NRF_ERROR_INVALID_STATE;
    }
 

    memset(&params, 0, sizeof(params));
    params.handle = p_ctx->BTS_TX_char_handles.value_handle;
    params.p_data = (uint8_t *)p_data;
    params.p_len  = &length;
    params.type   = BLE_GATT_HVX_NOTIFICATION;     
   
    sd_ble_gatts_hvx(p_ctx->conn_handle, &params);
}


