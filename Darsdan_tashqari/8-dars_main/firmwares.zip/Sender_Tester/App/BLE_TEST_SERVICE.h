#include "ble.h"
#include <stdint.h>
#include <stdbool.h>
#include "ble.h"
#include "ble_db_discovery.h"
#include "nrf_ble_gatt.h"

//
// UUID = bb4aff4f-ad03-415d-a96c-9d6cddda8304



#define BTS_UUID_BASE   {0x5f, 0x90, 0xec, 0x78, 0x60, 0xe6, 0x2c, 0x88, \
                             0x54, 0x43, 0x94, 0xa2, 0x6e, 0x60, 0x72, 0x19}

                             
#define SYNC2_char_params_UUID              0x1401 
#define CMD_BLE_UUID                        0x1402
#define BTS_TX_UUID                         0x1403 
#define BTS_SERVICE_UUID                    0x1400



/**************************************************************************************************/
/**************************************************************************************************/

/**
 * @defgroup nrf_ble_amt ATT MTU Throughput (AMT) Service Server
 * @{
 * @ingroup ble_sdk_srv
 *
 * @details  This module contains the APIs and types exposed by the ATT MTU Throughput
 *           Service Server module.
 *
 * @note     The application must propagate BLE stack events to this module by calling
 *           amt_on_ble_evt().
 */

#define BLE_AMTS_BLE_OBSERVER_PRIO   3

#ifdef __GNUC__
    #ifdef PACKED
        #undef PACKED
    #endif

    #define PACKED(TYPE) TYPE __attribute__ ((packed))
#endif




typedef PACKED( struct
{
    int16_t x;
    int16_t y;
    int16_t z;
}) sensor_sim_t2;





/**@brief AMT Server event type. */
typedef enum
{

    CUSTOMCH_EVT_NOTIF_ENABLED2,
    CUSTOMCH_EVT_NOTIF_DISABLED2,
    SYNC_INCOMING2,
    CMD_INCOMING,
    VALIDATE_SYNC2,
    BTS_TX_EVT_NOTIF_ENABLED,
    BTS_TX_EVT_NOTIF_DISABLED,

    
} nrf_ble_amts_evt_type_t2;


typedef struct
{
    uint16_t        att_mtu;                    /**< GATT ATT MTU, in bytes. */
    uint16_t        conn_interval;              /**< Connection interval expressed in units of 1.25 ms. */
    ble_gap_phys_t  phys;                       /**< Preferred PHYs. */
    uint8_t         data_len;                   /**< Data length. */
    bool            conn_evt_len_ext_enabled;   /**< Connection event length extension status. */
} test_params_t2;


typedef struct
{
    uint16_t        data1;                    
    uint16_t        data2;             
    uint16_t        data3;                      
    uint16_t        data4;                  
    uint16_t        data5;  
} data_t;



typedef enum
{
    SEND_SYNC,
    SET_POLLING_RATE,
    START_THROUGHPUT_TEST,   
} CMD_OPCODE_t;


typedef struct
{
    CMD_OPCODE_t        opcode;                    
    data_t              data;         
} cmd_t;



/**@brief AMTS Event structure. */
typedef struct
{
    nrf_ble_amts_evt_type_t2 evt_type;               //!< Type of the event. */
    uint32_t                 bytes_transfered_cnt;   //!< Number of bytes sent during the transfer*/
    test_params_t2           config_data;
    cmd_t                    command;

} nrf_ble_amts_evt_t2;


/**@brief AMTS module event handler type.
 * The AMTS module will call this function when notifications have been enabled/disabled, for each Kilobytes sent and at the end of the tranfer.
*/
typedef void (*amts_evt_handler_t2)(nrf_ble_amts_evt_t2);


/**@brief AMTS structure.
 * @details This structure contains status information for the AMTS module. */
typedef struct
{
    uint16_t                 conn_handle;           
    uint8_t                  uuid_type;           
    ble_gatts_char_handles_t CMD_BLE_char_handles;
    ble_gatts_char_handles_t SYNC_char_handles;
    ble_gatts_char_handles_t BTS_TX_char_handles;         
    amts_evt_handler_t2       evt_handler;         
   
} nrf_ble_amts_t2;





/**@brief   Function for handling BLE events from the SoftDevice.
 *
 * @details This function will handle the BLE events received from the SoftDevice.
 *          If a BLE event is relevant to the AMTS module, then it uses it to update
 *          interval variables and, if necessary, send events to the application.
 *
 * @param[in] p_ble_evt     Pointer to the BLE event.
 * @param     p_context     Pointer to the AMTS structure.
 */
void BTS_on_ble_evt(ble_evt_t const * p_ble_evt, void * p_context);


/**@brief   Function for initializing the ATT MTU Throughput Service module.
 *
 * @details This function will initialize the module and set up the ATT MTU Throughput Service.
 *
 * @param[out] p_ctx        Pointer to the AMTS structure.
 * @param[in]  evt_handler  Event handler.
 *
 * @retval     NRF_SUCCESS      Operation success.
 * @retval     NRF_ERROR_NULL   A parameter is NULL.
 */
void nrf_ble_amts_init2(nrf_ble_amts_t2 * p_ctx, amts_evt_handler_t2 evt_handler);


/**@brief   Function for sending AMT_BYTE_TRANSFER_CNT bytes via notifications.
 *
 * @details Call this function to start sending notifications until AMT_BYTE_TRANSFER_CNT bytes
 *          have been sent. Each notification will contain @p p_ctx::max_payload_len bytes of
 *          ATT payload.
 *
 * @param   p_ctx   Pointer to the AMTS structure.
 */
void nrf_ble_amts_notif_spam2(nrf_ble_amts_t2 * p_ctx);


/**@brief   Function for setting the the number of bytes received.
 *
 * @details Call this function to update the number of bytes received.
 *
 * @param       p_ctx     Pointer to the AMTS structure.
 * @param[in]   byte_cnt  Number of bytes received.
 */
void nrf_ble_amts_rbc_set2(nrf_ble_amts_t2 * p_ctx, uint32_t byte_cnt);


/**@brief   Function for handling the GATT module's events.
 *
 * @details Handles all events from the GATT module of interest to the AMT Service.
 *
 * @param       p_ctx         Pointer to the AMTS structure.
 * @param[in]   p_gatt_evt    Event received from the GATT module.
 */
void nrf_ble_amts_on_gatt_evt2(nrf_ble_amts_t2 * p_ctx, nrf_ble_gatt_evt_t const * p_gatt_evt);

/** @} */ // End tag for the Server.

void BTS_init(nrf_ble_amts_t2 * p_ctx, amts_evt_handler_t2 evt_handler);



/////////////
//CLIENT
///////////

//
//typedef PACKED( struct
//{
//    int16_t x;
//    int16_t y;
//    int16_t z;
//}) sensor_sim_t;
//


/**@brief Structure containing the handles found on the peer. */
typedef struct
{
    uint16_t amt_cccd_handle;               //!<  Handle of the CCCD . */
    uint16_t amt_handle;                    //!<  Handle of the characteristic as provided by the SoftDevice. */
    uint16_t CMD_BLE_char_handles;
    uint16_t amt_SYNC_char_handle;          //!<  Handle of the Number of received bytes  characteristic as provided by the SoftDevice. */
    uint16_t custom_char_handle;          //!<  Handle of the Number of received bytes  characteristic as provided by the SoftDevice. */
    uint16_t BTS_TX_cccd_handle;
    uint16_t BTS_TX_handle;
} nrf_ble_amtc_db_t2;

/**@brief AMT Client event type. */
typedef enum
{
    NRF_BLE_AMT_C_EVT_DISCOVERY_COMPLETE2,   //!<  Event indicating that the peer throughput Service has been discovered at the peer. */
    BTS_TX_RECEIVED_DATA,
} nrf_ble_amtc_evt_type_t2;


///**@brief AMT Notification structure. */
//typedef struct
//{
//    uint16_t notif_len;                     //!<  Length of the received notification.*/
//    uint32_t bytes_sent;                    //!<  Decoded number of bytes sent by the peer.*/
//    uint32_t bytes_rcvd;                    //!<  Number of bytes received from the peer since the beggining of the transfer.*/
//} nrf_ble_amtc_notif_t2;
//

/**@brief AMT Event structure. */
typedef struct
{
    nrf_ble_amtc_evt_type_t2 evt_type;       //!<  Type of the event. */
    uint16_t                conn_handle;    //!<  Connection handle on which the event  occurred.*/
    union
    {
        nrf_ble_amtc_db_t2    peer_db;       //!<  Handles found on the peer device. This will be filled if the evt_type is @ref NRF_BLE_AMT_C_EVT_DISCOVERY_COMPLETE.*/
                     //!<  Notification data. This will be filled if the evt_type is @ref NRF_BLE_AMT_C_EVT_NOTIFICATION.*/       
    } params;
    sensor_sim_t2 ReceivedSensorValues;   
} nrf_ble_amtc_evt_t2;


// Forward declaration of the nrf_ble_amtc_t type.
struct nrf_ble_amtc_t2;

/**@brief AMT Client module event handler type.
 * The AMT Client module will call this function when a matching server has been found on the peer and for each notification.
*/
typedef void (*nrf_ble_amtc_evt_handler_t2) (struct nrf_ble_amtc_t2 * p_ctx,
                                            nrf_ble_amtc_evt_t2    * p_evt);

/**@brief AMT_C structure.
 * @details This structure contains status information for the AMT client module. */
typedef struct nrf_ble_amtc_t2
{
    uint16_t                   conn_handle;      //!<  Connection handle as provided by the SoftDevice. */
    nrf_ble_amtc_db_t2          peer_db;          //!<  Handles on the peer*/
    nrf_ble_amtc_evt_handler_t2 evt_handler;      //!<  Application event handler to be called when there is an event related to this AMT Client Module. */
    uint8_t                    uuid_type;        //!<  UUID type. */
    uint32_t                   bytes_rcvd_cnt;   //!<  Number of bytes received.*/
} nrf_ble_amtc_t2;





/**@brief      Function for initializing the ATT MTU Throughput client module.
 *
 * @details    This function will initialize the module and set up Database Discovery to discover
 *             the ATT MTU Throughput Service. After calling this function, call @ref ble_db_discovery_start
 *             to start discovery once a link with a peer has been established.
 *
 * @param[out] p_ctx       Pointer to the AMT client structure.
 * @param[in]  evt_handler Event handler.
 *
 * @retval     NRF_SUCCESS      Operation success.
 * @retval     NRF_ERROR_NULL   A parameter is NULL.
 *                              Otherwise, an error code returned by @ref ble_db_discovery_evt_register.
 */
ret_code_t BTS_CLIENT_init(nrf_ble_amtc_t2 * p_ctx, nrf_ble_amtc_evt_handler_t2 evt_handler);


/**@brief     Function for handling BLE events from the SoftDevice.
 *
 * @details   This function will handle the BLE events received from the SoftDevice. If a BLE
 *            event is relevant to the AMT Client module, then it uses it to update
 *            interval variables and, if necessary, send events to the application.
 *
 * @param[in] p_ble_evt     Pointer to the BLE event.
 * @param[in] p_context     Pointer to the AMT client structure.
 */
void BTS_CLIENT_on_ble_evt(ble_evt_t const * p_ble_evt, void * p_context);


/**@brief   Function for enabling CCCD on the peer.
 *
 * @details This function will enable to notification of AMT at the peer
 *          by writing to the CCCD of the AMT Characteristic.
 *
 * @param   p_ctx Pointer to the AMT client structure.
 *
 * @retval  NRF_SUCCESS If the SoftDevice has been requested to write to the CCCD of the peer.
 *                      Otherwise, an error code. This function propagates the error code returned
 *                      by the SoftDevice API @ref sd_ble_gattc_write.
 */
ret_code_t BTS_CLIENT_notif_enable(nrf_ble_amtc_t2 * p_ctx);

ret_code_t tx_notif_enable2(nrf_ble_amtc_t2 * p_ctx);


/**@brief     Function for handling events from the database discovery module.
 *
 * @details   Call this function when getting a callback event from the DB discovery modue.
 *            This function will handle an event from the database discovery module, and determine
 *            if it relates to the discovery of AMT service at the peer. If so, it will
 *            call the application's event handler indicating that the AMT service has been
 *            discovered at the peer. It also populates the event with the service related
 *            information before providing it to the application.
 *
 * @param     p_ctx      Pointer to the AMT client structure.
 * @param[in] p_evt Pointer to the event received from the database discovery module.
 *
 */
void BTS_CLIENT_on_db_disc_evt(nrf_ble_amtc_t2 * p_ctx, const ble_db_discovery_evt_t * p_evt);


/**@brief     Function for assigning handles to a this instance of rscs_c.
 *
 * @details   Call this function when a link has been established with a peer to
 *            associate this link to this instance of the module. This makes it
 *            possible to handle several link and associate each link to a particular
 *            instance of this module. The connection handle and attribute handles will be
 *            provided from the discovery event @ref NRF_BLE_AMT_C_EVT_DISCOVERY_COMPLETE.
 *
 * @param     p_ctx          Pointer to the AMT client structure.
 * @param[in] conn_handle    Connection handle to associated with the given AMT Instance.
 * @param[in] p_peer_handles Attribute handles on the AMT server that you want this AMT client to
 *                           interact with.
 */
ret_code_t BTS_CLIENT_handles_assign(nrf_ble_amtc_t2    * p_ctx,
                                       uint16_t            conn_handle,
                                       nrf_ble_amtc_db_t2 * p_peer_handles);


/**@brief     Function for reading the Bytes Received Count (RCB) characteristic.
 *
 * @details   Call this function to read the RCB characteristic value on the peer.
 *
 * @param     p_ctx          Pointer to the AMT client structure.
 */
ret_code_t BTS_CLIENT_rcb_read(nrf_ble_amtc_t2 * p_ctx);


ret_code_t BTS_CLIENT_rcb_read(nrf_ble_amtc_t2 * p_ctx);
ret_code_t SEND_SYNC_BTS(nrf_ble_amtc_t2 * p_ctx, test_params_t2 config );

/** @} */ // End tag for the Client.
