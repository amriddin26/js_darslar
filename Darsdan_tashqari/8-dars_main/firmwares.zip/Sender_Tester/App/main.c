#include "init.h"
#include "app.h"

//#include "initCTXapp.h"

 

static bool debug=false; 


static uint32_t mainticks=0;
//static bool ctx = false;
void GetTime(void)
 {
//      advertising_start();
            counter_stop();
            uint32_t time_ms      = counter_get();
            debug=false;  
            mainticks=0;
            NRF_LOG_RAW_INFO("time in ms = %d\n", time_ms);
 }

 void StartTime(void)
 {
//      advertising_start();
        counter_start();
        debug=true;  
 }

  void toggleLed(void)
 {    
      if (bsp_board_led_state_get(1)) {
      bsp_board_led_off(1);
      }
      else {
      bsp_board_led_on(1);      
      }
      init_BLE_TEST_SERVICE();
   //    init_custom_char();
          
 }


void sync()
{
test_params_t2 config;
memcpy(&config, &m_test_params, sizeof(m_test_params));
SEND_SYNC_BTS(&m_BTSclt , config);
}







 void idle_task(void * p_context)
{
       
        for (;;)
        {
               if (is_test_ready())
               {
                   NRF_LOG_RAW_INFO("Test started");
                   m_run_test = true;
                   test_run();
               }      
                
                if (debug==true)
                {
                    
                    mainticks ++;
                    NRF_LOG_RAW_INFO("mainticks = %d\n", mainticks);  
                    //NRF_LOG_FLUSH();
                }    

                 if (tx_notif_enabled)
                 {
                  //   NRF_LOG_INFO("txtx");

                   tx_run();
                 // nrf_delay_ms(1); 
                   
                 }

                 if (BTS_tx_notif_enabled)
                 {
                 
                   tx_run2();
                  
                   
                 }
             //     if (NRF_LOG_PROCESS() == false)
             //   {
             //           nrf_pwr_mgmt_run();
             //   }
                task_yield();


        }
}



int main(void)
{      
        debug=false;
        // initializes basic modules for cli,ble,usb,clock,power_management,logger and IOs
        // Creates 2 virtual com device : 1 -> CLI , 2-> LOG-
        init_hardware();   
      //  init_bluetooth();
        init_software();

         

        // Start Task manager , idle task = main loop
        task_manager_start(idle_task, NULL);

}


/**
 * @}
 */
