#include "sdk_config.h"
#include "ble_db_discovery.h"
#include "ble_types.h"
#include "ble_srv_common.h"
#include "ble_gattc.h"
#include "sdk_common.h"
#include "BLE_TEST_SERVICE.h"

#define NRF_LOG_MODULE_NAME BTS_CLIENT
#include "nrf_log.h"
NRF_LOG_MODULE_REGISTER();

#define TX_BUFFER_MASK         0x07                  /**< TX Buffer mask, must be a mask of continuous zeroes, followed by continuous sequence of ones: 000...111. */
#define TX_BUFFER_SIZE         (TX_BUFFER_MASK + 1)  /**< Size of send buffer, which is 1 higher than the mask. */

#define WRITE_MESSAGE_LENGTH   BLE_CCCD_VALUE_LEN    /**< Length of the write message for CCCD. */

typedef enum
{
    READ_REQ,  /**< Type identifying that this tx_message is a read request. */
    WRITE_REQ  /**< Type identifying that this tx_message is a write request. */
} tx_request_t;

/**@brief Structure for writing a message to the peer, i.e. CCCD.
 */
typedef struct
{
    uint8_t                  gattc_value[WRITE_MESSAGE_LENGTH];  /**< The message to write. */
    ble_gattc_write_params_t gattc_params;                       /**< GATTC parameters for this message. */
} write_params_t;

/**@brief Structure for holding data to be transmitted to the connected central.
 */
typedef struct
{
    uint16_t     conn_handle;  /**< Connection handle to be used when transmitting this message. */
    tx_request_t type;         /**< Type of this message, i.e. read or write message. */
    union
    {
        uint16_t       read_handle;  /**< Read request message. */
        write_params_t write_req;    /**< Write request message. */
    } req;
} tx_message_t;

static tx_message_t   m_tx_buffer[TX_BUFFER_SIZE];  /**< Transmit buffer for messages to be transmitted to the central. */
static uint32_t       m_tx_insert_index = 0;        /**< Current index in the transmit buffer where the next message should be inserted. */
static uint32_t       m_tx_index = 0;               /**< Current index in the transmit buffer from where the next message to be transmitted resides. */


///**@brief Function for passing any pending request from the buffer to the stack.
// */
static void tx_buffer_process2(void)
{
    if (m_tx_index != m_tx_insert_index)
    {
        uint32_t err_code;

        if (m_tx_buffer[m_tx_index].type == READ_REQ)
        {
            err_code = sd_ble_gattc_read(m_tx_buffer[m_tx_index].conn_handle,
                                         m_tx_buffer[m_tx_index].req.read_handle,
                                         0);
        }
        else
        {
            err_code = sd_ble_gattc_write(m_tx_buffer[m_tx_index].conn_handle,
                                          &m_tx_buffer[m_tx_index].req.write_req.gattc_params);
        }

        if (err_code == NRF_SUCCESS)
        {
            m_tx_index++;
            m_tx_index &= TX_BUFFER_MASK;
        }
        else
        {
            NRF_LOG_DEBUG("SD Read/Write API returns error, will retry later.");
        }
    }
}


/**@brief     Function for handling Handle Value Notification received from the SoftDevice.
 *
 * @details   This function will uses the Handle Value Notification received from the SoftDevice
 *            and checks if it is a notification of the AMT from the peer.
 *            If it is, this function will send an event to the peer.
 *
 * @param[in] p_ctx        Pointer to the AMT Client structure.
 * @param[in] p_ble_evt    Pointer to the BLE event received.
 */
static void on_hvx(nrf_ble_amtc_t2 * p_ctx, ble_evt_t const * p_ble_evt)
{
    // Check if the event if on the link for this instance
    if (p_ctx->conn_handle != p_ble_evt->evt.gattc_evt.conn_handle)
    {
        return;
    }

    // Check if this is a AMT notification.
    if (p_ble_evt->evt.gattc_evt.params.hvx.handle == p_ctx->peer_db.BTS_TX_handle)
    {
        

      
       // NRF_LOG_RAW_INFO("sending values X: %u Y: %u Z:%u ",p_ble_evt->evt.gattc_evt.params.hvx.data[0],p_ble_evt->evt.gattc_evt.params.hvx.data[1],p_ble_evt->evt.gattc_evt.params.hvx.data[2] );
        nrf_ble_amtc_evt_t2 amt_c_evt;  
        amt_c_evt.evt_type              = BTS_TX_RECEIVED_DATA;
        amt_c_evt.conn_handle           = p_ble_evt->evt.gattc_evt.conn_handle;
        
        // pointer gymanstic level : first appreciation
        amt_c_evt.ReceivedSensorValues  =  *(sensor_sim_t2*) &p_ble_evt->evt.gattc_evt.params.hvx.data[0];

        p_ctx->evt_handler(p_ctx, &amt_c_evt);
    }
}


/**@brief     Function for handling read response event received from the SoftDevice.
 *
 * @details   This function will uses the read response received from the SoftDevice
 *            and checks if it is a read response of the AMT from the peer.
 *            If it is, this function will send an event to the peer.
 *
 * @param[in] p_ctx        Pointer to the AMT Client structure.
 * @param[in] p_ble_evt    Pointer to the BLE event received.
 */
static void on_read_response(nrf_ble_amtc_t2 * p_ctx, ble_evt_t const * p_ble_evt)
{
    // Check if the event if on the link for this instance
    if (p_ctx->conn_handle != p_ble_evt->evt.gattc_evt.conn_handle)
    {
        return;
    }

   // // Check if this is a AMT RCB read response.
   // if (p_ble_evt->evt.gattc_evt.params.read_rsp.handle == p_ctx->peer_db.amt_rbc_handle)
   // {
   //     nrf_ble_amtc_evt_t amt_c_evt;
   //     amt_c_evt.evt_type             = NRF_BLE_AMT_C_EVT_RBC_READ_RSP;
   //     amt_c_evt.conn_handle          = p_ble_evt->evt.gattc_evt.conn_handle;
   //     amt_c_evt.params.rcv_bytes_cnt = uint32_decode(p_ble_evt->evt.gattc_evt.params.read_rsp.data);
   //     p_ctx->evt_handler(p_ctx, &amt_c_evt);
   // }
}


/**@brief     Function for handling write response event received from the SoftDevice.
 *
 * @details   This function will uses the read response received from the SoftDevice
 *            and checks if it is a write response of the AMT from the peer.
 *
 * @param[in] p_ctx        Pointer to the AMT Client structure.
 * @param[in] p_ble_evt    Pointer to the BLE event received.
 */
static void on_write_response(nrf_ble_amtc_t2 * p_ctx, ble_evt_t const * p_ble_evt)
{
    // Check if the event if on the link for this instance
    if (p_ctx->conn_handle != p_ble_evt->evt.gattc_evt.conn_handle)
    {
        return;
    }

  //  // Check if this is a write response on the CCCD.
  //  if (p_ble_evt->evt.gattc_evt.params.write_rsp.handle == p_ctx->peer_db.amt_cccd_handle)
  //  {
  //      NRF_LOG_DEBUG("CCCD configured.");
  //  }
}


void BTS_CLIENT_on_db_disc_evt(nrf_ble_amtc_t2 * p_ctx, ble_db_discovery_evt_t const * p_evt)
{
    // Check if the AMT service was discovered.
    if (   (p_evt->evt_type != BLE_DB_DISCOVERY_COMPLETE)
        || (p_evt->params.discovered_db.srv_uuid.uuid != BTS_SERVICE_UUID)
        || (p_evt->params.discovered_db.srv_uuid.type != p_ctx->uuid_type))
    {
        return;
    }
    NRF_LOG_INFO("BTS service discovered at peer.");

    nrf_ble_amtc_evt_t2 evt;
    evt.conn_handle = p_evt->conn_handle;
   
   // // Find the CCCD Handle of the AMT characteristic.
   for (uint32_t i = 0; i < p_evt->params.discovered_db.char_count; i++)
    {
        ble_uuid_t uuid = p_evt->params.discovered_db.charateristics[i].characteristic.uuid;  
      
   
        if ((uuid.uuid == SYNC2_char_params_UUID) && (uuid.type == p_ctx->uuid_type))
        {
            // Found AMT Number of received bytes characteristic. Store handles.
            evt.params.peer_db.amt_SYNC_char_handle =
                p_evt->params.discovered_db.charateristics[i].characteristic.handle_value;
        }

        if ((uuid.uuid == BTS_TX_UUID) && (uuid.type == p_ctx->uuid_type))
        {
            // Found AMT characteristic. Store handles.
            evt.params.peer_db.BTS_TX_cccd_handle =
                p_evt->params.discovered_db.charateristics[i].cccd_handle;
            evt.params.peer_db.BTS_TX_handle =
                p_evt->params.discovered_db.charateristics[i].characteristic.handle_value;
        }


           
        if ((uuid.uuid == CMD_BLE_UUID) && (uuid.type == p_ctx->uuid_type))
        {
          
            evt.params.peer_db.CMD_BLE_char_handles =
                p_evt->params.discovered_db.charateristics[i].characteristic.handle_value;
                NRF_LOG_INFO("CMD_BLE_UUID Handle assigned.");
        }
    }
   
    
  //  //If the instance has been assigned prior to db_discovery, assign the db_handles.
  //  if (p_ctx->conn_handle != BLE_CONN_HANDLE_INVALID)
  //  {
  //      if (   (p_ctx->peer_db.amt_cccd_handle == BLE_GATT_HANDLE_INVALID)
  //          && (p_ctx->peer_db.amt_handle == BLE_GATT_HANDLE_INVALID))
  //      {
  //          p_ctx->peer_db = evt.params.peer_db;
  //      }
  //  }
  //


   
    p_ctx->bytes_rcvd_cnt = 0;
   
    evt.evt_type = NRF_BLE_AMT_C_EVT_DISCOVERY_COMPLETE2;
    p_ctx->evt_handler(p_ctx, &evt);
}  


ret_code_t BTS_CLIENT_init(nrf_ble_amtc_t2 * p_ctx, nrf_ble_amtc_evt_handler_t2 evt_handler)
{
    VERIFY_PARAM_NOT_NULL(p_ctx);
    VERIFY_PARAM_NOT_NULL(evt_handler);

    ble_uuid128_t base_uuid = {BTS_UUID_BASE};
    ble_uuid_t    amt_uuid;

    ret_code_t err_code = sd_ble_uuid_vs_add(&base_uuid, &p_ctx->uuid_type);
    VERIFY_SUCCESS(err_code);

    amt_uuid.type = p_ctx->uuid_type;
    amt_uuid.uuid = BTS_SERVICE_UUID;

    p_ctx->evt_handler             = evt_handler;
    p_ctx->bytes_rcvd_cnt          = 0;
    p_ctx->conn_handle             = BLE_CONN_HANDLE_INVALID;
    p_ctx->peer_db.amt_cccd_handle = BLE_GATT_HANDLE_INVALID;
    p_ctx->peer_db.amt_handle      = BLE_GATT_HANDLE_INVALID;
    p_ctx->conn_handle             = BLE_CONN_HANDLE_INVALID;
    p_ctx->peer_db.amt_SYNC_char_handle  = BLE_GATT_HANDLE_INVALID;
    p_ctx->peer_db.CMD_BLE_char_handles=BLE_GATT_HANDLE_INVALID;


    return ble_db_discovery_evt_register(&amt_uuid);
}


ret_code_t BTS_CLIENT_handles_assign(nrf_ble_amtc_t2   * p_ctx,
                                      uint16_t            conn_handle,
                                      nrf_ble_amtc_db_t2 * p_peer_handles)
{
    VERIFY_PARAM_NOT_NULL(p_ctx);
    p_ctx->conn_handle = conn_handle;
    if (p_peer_handles != NULL)
    {
        p_ctx->peer_db = *p_peer_handles;
    }
    NRF_LOG_INFO("Handles assigned: Conn handle:0x%x  ",conn_handle);


    return NRF_SUCCESS;
}

//
///**@brief     Function for handling Disconnected event received from the SoftDevice.
// *
// * @details   This function check if the disconnect event is happening on the link
// *            associated with the current instance of the module, if so it will set its
// *            conn_handle to invalid.
// *
// * @param[in] p_ctx       Pointer to the AMT Client structure.
// * @param[in] p_ble_evt   Pointer to the BLE event received.
// */
//static void on_disconnected(nrf_ble_amtc_t * p_ctx, ble_evt_t const * p_ble_evt)
//{
//    if (p_ctx->conn_handle != p_ble_evt->evt.gap_evt.conn_handle)
//    {
//        return;
//    }
//
//    p_ctx->conn_handle             = BLE_CONN_HANDLE_INVALID;
//    p_ctx->peer_db.amt_cccd_handle = BLE_GATT_HANDLE_INVALID;
//    p_ctx->peer_db.amt_handle      = BLE_GATT_HANDLE_INVALID;
//    p_ctx->peer_db.amt_rbc_handle  = BLE_GATT_HANDLE_INVALID;
//
//
//
//    p_ctx->bytes_rcvd_cnt          = 0;
//    
//    p_ctx->peer_db.custom_char_handle     = BLE_GATT_HANDLE_INVALID;
//    p_ctx->peer_db.amt_SYNC_char_handle  = BLE_GATT_HANDLE_INVALID;
//
//
//}
//
//
void BTS_CLIENT_on_ble_evt(ble_evt_t const * p_ble_evt, void * p_context)
{
    nrf_ble_amtc_t2 * p_ctx = (nrf_ble_amtc_t2 *)p_context;
   
    if ((p_ctx == NULL) || (p_ble_evt == NULL))
    {
        return;
    }
   
    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GATTC_EVT_HVX:
            on_hvx(p_ctx, p_ble_evt);
            break;
   
   //     case BLE_GAP_EVT_DISCONNECTED:
   //         on_disconnected(p_ctx, p_ble_evt);
   //         break;
   //
   //     case BLE_GATTC_EVT_WRITE_RSP:
   //         on_write_response(p_ctx, p_ble_evt);
   //         break;
   //
   //     case BLE_GATTC_EVT_READ_RSP:
   //         on_read_response(p_ctx, p_ble_evt);
   //         break;
   //
        default:
            break;
    }
    // Check if the event if on the link for this instance
    if (p_ctx->conn_handle != p_ble_evt->evt.gattc_evt.conn_handle)
    {
        return;
    }
    // Check if there is any message to be sent across to the peer and send it.
    tx_buffer_process2();
   
}
//
//
///**@brief Function for creating a message for writing to the CCCD.
// */
static ret_code_t start_TX(uint16_t conn_handle, uint16_t handle_cccd, bool enable)
{
 
    tx_message_t * p_msg;
    uint16_t       cccd_val = enable ? BLE_GATT_HVX_NOTIFICATION : 0;

    p_msg              = &m_tx_buffer[m_tx_insert_index++];
    m_tx_insert_index &= TX_BUFFER_MASK;

    p_msg->req.write_req.gattc_params.handle   = handle_cccd;
    p_msg->req.write_req.gattc_params.len      = WRITE_MESSAGE_LENGTH;
    p_msg->req.write_req.gattc_params.p_value  = p_msg->req.write_req.gattc_value;
    p_msg->req.write_req.gattc_params.offset   = 0;
    p_msg->req.write_req.gattc_params.write_op = BLE_GATT_OP_WRITE_REQ;
    p_msg->req.write_req.gattc_value[0]        = LSB_16(cccd_val);
    p_msg->req.write_req.gattc_value[1]        = MSB_16(cccd_val);
    p_msg->conn_handle                         = conn_handle;
    p_msg->type                                = WRITE_REQ;

    tx_buffer_process2();

    return NRF_SUCCESS;
}


//
//
//
//
//
/**@brief Function for creating a message for writing to the CCCD.
 *///uint32_t ble_lbs_led_status_send(ble_lbs_c_t * p_ble_lbs_c, uint8_t status)
static ret_code_t SEND_SYNCsc(uint16_t conn_handle,uint16_t handle_cccd, test_params_t2 status)
{

    
     VERIFY_PARAM_NOT_NULL(conn_handle);

        if (conn_handle == BLE_CONN_HANDLE_INVALID)
    {
        return NRF_ERROR_INVALID_STATE;
    }
    NRF_LOG_INFO("Sending sync1");
    tx_message_t * p_msg; 

    p_msg              = &m_tx_buffer[m_tx_insert_index++];
    m_tx_insert_index &= TX_BUFFER_MASK;

    p_msg->req.write_req.gattc_params.handle   = handle_cccd;
    p_msg->req.write_req.gattc_params.len      = sizeof(test_params_t2);

    p_msg->req.write_req.gattc_params.p_value  = &status;
    p_msg->req.write_req.gattc_params.offset   = 0;
    p_msg->req.write_req.gattc_params.write_op = BLE_GATT_OP_WRITE_CMD;    

    p_msg->conn_handle                         = conn_handle;
    p_msg->type                                = WRITE_REQ;
  
    tx_buffer_process2();
    return NRF_SUCCESS;  
}


static ret_code_t SEND_CMDc(uint16_t conn_handle,uint16_t handle_cccd, cmd_t p_cmd)
{

    
     VERIFY_PARAM_NOT_NULL(conn_handle);

        if (conn_handle == BLE_CONN_HANDLE_INVALID)
    {
        return NRF_ERROR_INVALID_STATE;
    }
    NRF_LOG_INFO("Sending COMMAND");
    tx_message_t * p_msg; 

    p_msg              = &m_tx_buffer[m_tx_insert_index++];
    m_tx_insert_index &= TX_BUFFER_MASK;

    p_msg->req.write_req.gattc_params.handle   = handle_cccd;
    p_msg->req.write_req.gattc_params.len      = sizeof(cmd_t);

    p_msg->req.write_req.gattc_params.p_value  = &p_cmd;
    p_msg->req.write_req.gattc_params.offset   = 0;
    p_msg->req.write_req.gattc_params.write_op = BLE_GATT_OP_WRITE_CMD;    

    p_msg->conn_handle                         = conn_handle;
    p_msg->type                                = WRITE_REQ;
  
    tx_buffer_process2();
    return NRF_SUCCESS;  
}


ret_code_t SEND_SYNC_BTS(nrf_ble_amtc_t2 * p_ctx,test_params_t2 p_config)
{
    VERIFY_PARAM_NOT_NULL(p_ctx);

    if (p_ctx->conn_handle == BLE_CONN_HANDLE_INVALID)
    {
        return NRF_ERROR_INVALID_STATE;
    }
    
 NRF_LOG_INFO("Sending sync");
 return SEND_SYNCsc(p_ctx->conn_handle, p_ctx->peer_db.amt_SYNC_char_handle, p_config);   
}


ret_code_t SEND_CMD_BTS(nrf_ble_amtc_t2 * p_ctx,cmd_t p_cmd)
{
    VERIFY_PARAM_NOT_NULL(p_ctx);

    if (p_ctx->conn_handle == BLE_CONN_HANDLE_INVALID)
    {
        return NRF_ERROR_INVALID_STATE;
    }
    
 NRF_LOG_INFO("Sending OPCODE: ");
 NRF_LOG_INFO("OP code: d% Data: d% " ,p_cmd.opcode,p_cmd.data.data1);

 return SEND_CMDc(p_ctx->conn_handle, p_ctx->peer_db.CMD_BLE_char_handles , p_cmd);   
}



ret_code_t BTS_tx_notif_enable(nrf_ble_amtc_t2 * p_ctx, bool A)
{
    VERIFY_PARAM_NOT_NULL(p_ctx);
 
    if (p_ctx->conn_handle == BLE_CONN_HANDLE_INVALID)
    {
        NRF_LOG_ERROR("invalid handle");
        return NRF_ERROR_INVALID_STATE;
    }

    return start_TX(p_ctx->conn_handle, p_ctx->peer_db.BTS_TX_cccd_handle , A);
}
//
//ret_code_t nrf_ble_amtc_rcb_read(nrf_ble_amtc_t * p_ctx)
//{
//    VERIFY_PARAM_NOT_NULL(p_ctx);
//
//    if (p_ctx->conn_handle == BLE_CONN_HANDLE_INVALID)
//    {
//        return NRF_ERROR_INVALID_STATE;
//    }
//
//    tx_message_t * p_msg = &m_tx_buffer[m_tx_insert_index++];
//
//    p_msg->req.read_handle = p_ctx->peer_db.amt_rbc_handle;
//    p_msg->conn_handle     = p_ctx->conn_handle;
//    p_msg->type            = READ_REQ;
//
//    m_tx_insert_index &= TX_BUFFER_MASK;
//    tx_buffer_process();
//
//    return NRF_SUCCESS;
//}
//
//
//
//
//
//
///** @}
// *  @endcond
// */
//