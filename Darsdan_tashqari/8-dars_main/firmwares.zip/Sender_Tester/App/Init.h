/**
 * Copyright (c) 2015 - 2019, Nordic Semiconductor ASA
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 *
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
/**
 * @brief Blinky Sample Application main file.
 *
 * This file contains the source code for a sample server application using the LED Button service.
 */




#include "nrf_pwr_mgmt.h"
#include "nrf_drv_clock.h"
#include "nrf_gpio.h"
#include "nrf_delay.h"
#include "fds.h"
#include "nrf_cli.h"
#include "nrf_cli_rtt.h"
#include "nrf_cli_types.h"
#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"
#include "nrf_log_backend_flash.h"
#include "nrf_fstorage_nvmc.h"
#include "nrf_fstorage_sd.h"
#include "nrf_mpu_lib.h"
#include "nrf_stack_guard.h"
#include "boards.h"



#if defined(APP_USBD_ENABLED) && APP_USBD_ENABLED
#define CLI_OVER_USB_CDC_ACM 1
#else
#define CLI_OVER_USB_CDC_ACM 0
#endif

#if CLI_OVER_USB_CDC_ACM
#include "nrf_cli_cdc_acm.h"
#include "nrf_drv_usbd.h"
#include "app_usbd_core.h"
#include "app_usbd.h"
#include "app_usbd_string_desc.h"
#include "app_usbd_cdc_acm.h"
#endif //CLI_OVER_USB_CDC_ACM

#if 0//defined(TX_PIN_NUMBER) && defined(RX_PIN_NUMBER)
#define CLI_OVER_UART 1
#else
#define CLI_OVER_UART 0
#endif

#if CLI_OVER_UART
#include "nrf_cli_uart.h"
#endif

/* If enabled then CYCCNT (high resolution) timestamp is used for the logger. */
#define USE_CYCCNT_TIMESTAMP_FOR_LOG 1


#define DEAD_BEEF                       0xDEADBEEF                              /**< Value used as error code on stack dump, can be used to identify stack location on stack unwind. */



//
//
//#if NRF_LOG_BACKEND_FLASHLOG_ENABLED
//NRF_LOG_BACKEND_FLASHLOG_DEF(m_flash_log_backend);
//#endif
//
//#if NRF_LOG_BACKEND_CRASHLOG_ENABLED
//NRF_LOG_BACKEND_CRASHLOG_DEF(m_crash_log_backend);
//#endif
//


#if CLI_OVER_USB_CDC_ACM

/**
 * @brief Enable power USB detection
 *
 * Configure if example supports USB port connection
 */
#ifndef USBD_POWER_DETECTION
#define USBD_POWER_DETECTION true
#endif




static void usbd_user_ev_handler(app_usbd_event_type_t event)
{
        switch (event)
        {
        case APP_USBD_EVT_STOPPED:
                app_usbd_disable();
                break;
        case APP_USBD_EVT_POWER_DETECTED:
                if (!nrf_drv_usbd_is_enabled())
                {
                        app_usbd_enable();
                }
                break;
        case APP_USBD_EVT_POWER_REMOVED:
                app_usbd_stop();
                break;
        case APP_USBD_EVT_POWER_READY:
                app_usbd_start();
                break;
        default:
                break;
        }
}

#endif //CLI_OVER_USB_CDC_ACM


/**
 * @brief Command line interface instance
 * */
#define CLI_EXAMPLE_LOG_QUEUE_SIZE  (16)
NRF_CLI_CDC_ACM_DEF(m_cli_cdc_acm_transport);
NRF_CLI_DEF(m_cli_cdc_acm,"Commander: ",&m_cli_cdc_acm_transport.transport,'\n',CLI_EXAMPLE_LOG_QUEUE_SIZE);







static void cli_start(void)
{
        ret_code_t ret;
        ret = nrf_cli_start(&m_cli_cdc_acm);
        APP_ERROR_CHECK(ret);

}

static void cli_init(void)
{
        ret_code_t ret;
        ret = nrf_cli_init(&m_cli_cdc_acm, NULL, true, true, NRF_LOG_SEVERITY_INFO);
        APP_ERROR_CHECK(ret);
}

static void usbd_init(void)
{
        ret_code_t ret;
        static const app_usbd_config_t usbd_config = {
                .ev_handler = app_usbd_event_execute,
                .ev_state_proc = usbd_user_ev_handler
        };
        ret = app_usbd_init(&usbd_config);
        APP_ERROR_CHECK(ret);
        app_usbd_class_inst_t const * class_cdc_acm =
                app_usbd_cdc_acm_class_inst_get(&nrf_cli_cdc_acm);
        ret = app_usbd_class_append(class_cdc_acm);
        APP_ERROR_CHECK(ret);

}

static void usbd_enable(void)
{
        ret_code_t ret;
        if (USBD_POWER_DETECTION)
        {
                ret = app_usbd_power_events_enable();
                APP_ERROR_CHECK(ret);
        }
        else
        {
                NRF_LOG_INFO("No USB power detection enabled\nStarting USB now");

                app_usbd_enable();
                app_usbd_start();
        }

        /* Give some time for the host to enumerate and connect to the USB CDC port */
        nrf_delay_ms(500);

//#endif
}


//static void flashlog_init(void)
//{
//        ret_code_t ret;
//        int32_t backend_id;
//        ret = nrf_log_backend_flash_init(&nrf_fstorage_sd);
//        APP_ERROR_CHECK(ret);
//
//#if NRF_LOG_BACKEND_FLASHLOG_ENABLED
//        backend_id = nrf_log_backend_add(&m_flash_log_backend, NRF_LOG_SEVERITY_WARNING);
//        APP_ERROR_CHECK_BOOL(backend_id >= 0);
//        nrf_log_backend_enable(&m_flash_log_backend);
//#endif
//
//#if NRF_LOG_BACKEND_CRASHLOG_ENABLED
//        backend_id = nrf_log_backend_add(&m_crash_log_backend, NRF_LOG_SEVERITY_INFO);
//        APP_ERROR_CHECK_BOOL(backend_id >= 0);
//        nrf_log_backend_enable(&m_crash_log_backend);
//#endif
//}
//
static inline void stack_guard_init(void)
{
        APP_ERROR_CHECK(nrf_mpu_lib_init());
        APP_ERROR_CHECK(nrf_stack_guard_init());
}

uint32_t cyccnt_get(void)
{
        return DWT->CYCCNT;
}


/**@brief Function for assert macro callback.
 *
 * @details This function will be called in case of an assert in the SoftDevice.
 *
 * @warning This handler is an example only and does not fit a final product. You need to analyze
 *          how your product is supposed to react in case of Assert.
 * @warning On assert from the SoftDevice, the system can only recover on reset.
 *
 * @param[in] line_num    Line number of the failing ASSERT call.
 * @param[in] p_file_name File name of the failing ASSERT call.
 */
///////void assert_nrf_callback(uint16_t line_num, const uint8_t * p_file_name)
///////{
///////        app_error_handler(DEAD_BEEF, line_num, p_file_name);
///////}
///////

/**@brief Function for the LEDs initialization.
 *
 * @details Initializes all LEDs used by the application.
 */
static void leds_init(void)
{
        bsp_board_init(BSP_INIT_LEDS);
}

///////
////////**@brief Function for the Timer initialization.
/////// *
/////// * @details Initializes the timer module.
/////// */
///////static void timers_init(void)
///////{
///////        // Initialize timer module, making it use the scheduler
///////        ret_code_t err_code = app_timer_init();
///////        APP_ERROR_CHECK(err_code);
///////}
///////







static void log_init(void)
{
        ret_code_t err_code = NRF_LOG_INIT(NULL);
        APP_ERROR_CHECK(err_code);
        NRF_LOG_DEFAULT_BACKENDS_INIT();
}


/**@brief Function for initializing loggerpart.
 */
static void logger_weird_init(void)
{
            if (USE_CYCCNT_TIMESTAMP_FOR_LOG)
        {
                CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
                DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
                DWT->CYCCNT = 0;
                APP_ERROR_CHECK(NRF_LOG_INIT(cyccnt_get, 64000000));
        }
        else
        {
                APP_ERROR_CHECK(NRF_LOG_INIT(app_timer_cnt_get));
        }
}


/**@brief Function for initializing power management.
 */
static void power_management_init(void)
{
        ret_code_t err_code;
        err_code = nrf_pwr_mgmt_init();
        APP_ERROR_CHECK(err_code);
}





void init_hardware(void)
{

        APP_ERROR_CHECK(nrf_drv_clock_init());
        nrf_drv_clock_lfclk_request(NULL);
       
        leds_init();
       
      //  timers_init();
        stack_guard_init();
        cli_init();
        usbd_init();
        nrf_delay_ms(1000);
        log_init();
      //  usbd_enable();
       // nrf_delay_ms(4000);

        power_management_init();

        APP_ERROR_CHECK(fds_init());
//        UNUSED_RETURN_VALUE(nrf_log_config_load());
   //     APP_ERROR_CHECK(nrf_cli_task_create(&m_cli_cdc_acm));
//        flashlog_init();

}