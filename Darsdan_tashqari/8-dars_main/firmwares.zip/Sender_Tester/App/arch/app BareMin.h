

/* Counter timer. */
APP_TIMER_DEF(m_timer_0);

/* Declared in demo_cli.c */
extern uint32_t m_counter;
extern bool m_counter_active;

static void timer_handle(void * p_context)
{
        UNUSED_PARAMETER(p_context);

        if (m_counter_active)
        {
                m_counter++;
                NRF_LOG_RAW_INFO("counter = %d\n", m_counter);             
        }
}


void init_software(void)
{     
        timers_init();      
        APP_ERROR_CHECK(app_timer_create(&m_timer_0, APP_TIMER_MODE_REPEATED, timer_handle));
        APP_ERROR_CHECK(app_timer_start(m_timer_0, APP_TIMER_TICKS(1), NULL));
     
  
}



